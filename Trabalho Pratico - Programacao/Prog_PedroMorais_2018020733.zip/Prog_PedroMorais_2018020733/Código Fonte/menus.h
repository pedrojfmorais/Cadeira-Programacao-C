#ifndef MENUS_H_INCLUDED
#define MENUS_H_INCLUDED

#include "jogadores.h"

//declara��o das fun��es criadas no ficheiro "menus.c"
void menuPrincipal();
void menuJogadas(jogadores jogador);

#endif // MENUS_H_INCLUDED
